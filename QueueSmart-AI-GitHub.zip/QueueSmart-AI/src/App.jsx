import React from 'react';

/**
 * The original Claude Artifact is preserved as a standalone application in
 * public/queuesmart.html. Hosting it at the same origin keeps its localStorage
 * persistence and all existing queue interactions intact while providing a
 * standard React + Vite project for development and GitHub.
 */
export default function App() {
  return (
    <main className="app-shell" aria-label="QueueSmart AI application">
      <iframe
        className="app-frame"
        src="/queuesmart.html"
        title="QueueSmart AI queue management dashboard"
        allow="clipboard-read; clipboard-write"
      />
    </main>
  );
}
