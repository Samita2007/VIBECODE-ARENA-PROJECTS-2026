# QueueSmart AI

QueueSmart AI is a browser-based queue management prototype for hospitals, banks, government offices, and service centres. It demonstrates digital queue registration, token generation, appointment booking, waiting-time estimates, live queue monitoring, simulated notifications, and administrative queue controls.

## Features

- Customer walk-in registration and unique tokens
- Appointment booking with dynamically generated hourly slots and a maximum of eight bookings per slot
- Appointment check-in kept separate from the walk-in queue
- Asia/Kolkata time display and time-based appointment availability
- Estimated waiting times based on eligible customers and available counters
- Live queue, serving, completed, skipped, and appointment views
- Counter management and queue allocation recommendations
- Transparent configurable priority categories
- Simulated in-app notifications and basic operational statistics
- Responsive interface and browser `localStorage` persistence

## Technology

- React
- Vite
- JavaScript and CSS
- Original functional Claude Artifact preserved in `public/queuesmart.html`

## Run locally

Install a current Node.js LTS release, then run:

```bash
npm install
npm run dev
```

Open the local URL printed by Vite in your browser.

## Production build

```bash
npm run build
npm run preview
```

The production files are generated in `dist/`.

## GitHub upload

Upload the contents of this project folder to a GitHub repository. Do not upload `node_modules/` or `dist/`; they are generated locally and ignored by Git.

## Demo data and limitations

This is a prototype. Queue records are stored in the current browser's `localStorage`; they are not shared between different devices or browsers. Notifications are simulated in-app notifications; no real SMS or email is sent. No external database, payment system, or production authentication is configured. Waiting times are estimates, not guarantees. The React/Vite shell hosts the original standalone implementation to preserve the existing Artifact's behaviour and styling.
